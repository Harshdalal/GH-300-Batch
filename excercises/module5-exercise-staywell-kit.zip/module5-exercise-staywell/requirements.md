# StayWell hotel booking: requirements

The product owner agreed these rules. This file is the source of truth.
All money is in whole rupees (int). Dates are datetime.date. A night belongs to the date
the guest sleeps there: a stay from Friday to Sunday has a Friday night and a Saturday night.

## R1. Stay price  (src/pricing.py)

New code uses stay_price(check_in, check_out, nightly_rate). Old callers still use
calc(a, b, r): it must keep working and return the same value as stay_price.

- nights = number of days from check_in to check_out. Fewer than 1 night raises ValueError.
- Friday and Saturday nights cost 25% more than nightly_rate. Every other night costs nightly_rate.
- Each night's price is rounded half up to a whole rupee (1252.5 becomes 1253).
- Stays of 7 nights or more get 10% off the total, rounded half up to a whole rupee.
- Returns an int.

Calendar used in the examples: 2026-11-02 is a Monday, 2026-11-06 a Friday,
2026-11-07 a Saturday.

| ID | check_in   | check_out  | nightly_rate | expected   | why                                |
|----|------------|------------|--------------|------------|------------------------------------|
| 1  | 2026-11-02 | 2026-11-04 | 2000         | 4000       | Mon and Tue nights                 |
| 2  | 2026-11-06 | 2026-11-08 | 2000         | 5000       | Fri and Sat nights, both +25%      |
| 3  | 2026-11-02 | 2026-11-09 | 2000         | 13500      | 7 nights: 15000, then 10% off      |
| 4  | 2026-11-06 | 2026-11-07 | 999          | 1249       | Fri night: 1248.75 rounds to 1249  |
| 5  | 2026-11-07 | 2026-11-08 | 1000         | 1250       | Sat night                          |
| 6  | 2026-11-07 | 2026-11-08 | 1002         | 1253       | Sat night: 1252.5 rounds up        |
| 7  | 2026-11-02 | 2026-11-02 | 2000         | ValueError | 0 nights                           |
| 8  | 2026-11-04 | 2026-11-02 | 2000         | ValueError | check_out before check_in          |

## R2. Free rooms  (src/availability.py)

free_rooms(room_ids, bookings, check_in, check_out) returns the rooms with no booking that
overlaps the stay, in the same order as room_ids. bookings is a list of
(room_id, start, end). Guests leave on the end date, so a booking ending on check_in does not
overlap, and a booking starting on check_out does not overlap.
check_out on or before check_in raises ValueError.

Example data: room_ids = [101, 102, 103]
bookings = [(101, 2026-11-02, 2026-11-05), (102, 2026-11-05, 2026-11-07)]

| ID | check_in   | check_out  | expected        | why                                   |
|----|------------|------------|-----------------|---------------------------------------|
| 1  | 2026-11-05 | 2026-11-06 | [101, 103]      | 101 checks out on the 5th: free       |
| 2  | 2026-11-01 | 2026-11-02 | [101, 102, 103] | 101's booking starts on check_out     |
| 3  | 2026-11-03 | 2026-11-04 | [102, 103]      | 101 is booked                         |
| 4  | 2026-11-06 | 2026-11-06 | ValueError      | no nights                             |

Performance: the hotel chain has up to 3,000 rooms and 30,000 bookings.
A search must take well under one second on a laptop (bench.py measures it).

## R3. Find a guest  (src/guests.py)

find_guest(conn, email) returns (id, name, email) for an exact email match, or None.
The email is always data: it must never be able to change the SQL.

| ID | email               | expected                                 |
|----|---------------------|------------------------------------------|
| 1  | asha@example.com    | (1, "Asha Rao", "asha@example.com")      |
| 2  | nobody@example.com  | None                                     |
| 3  | x' OR '1'='1        | None                                     |
