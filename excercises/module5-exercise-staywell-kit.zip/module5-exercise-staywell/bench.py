"""Time one free_rooms search with 3,000 rooms and 30,000 bookings. Do not change this file.

Run: python bench.py
"""
import datetime
import random
import time

from src.availability import free_rooms

random.seed(7)
start_day = datetime.date(2026, 11, 1)
rooms = list(range(1, 3001))
bookings = []
for _ in range(30_000):
    room = random.choice(rooms)
    begin = start_day + datetime.timedelta(days=random.randint(0, 90))
    bookings.append((room, begin, begin + datetime.timedelta(days=random.randint(1, 5))))

t0 = time.perf_counter()
result = free_rooms(rooms, bookings, datetime.date(2026, 11, 20), datetime.date(2026, 11, 22))
seconds = time.perf_counter() - t0
print(f"{len(result)} free rooms, search took {seconds:.3f} seconds")
