# Module 5 practice exercise kit: StayWell hotel booking

Practice for Module 5 (Improve developer productivity with GitHub Copilot). Do the main
case study first. Follow the tasks in Module5_Exercise_Problem_Statement.docx and write your
own prompts.

- requirements.md         the rules R1 to R3 with agreed examples (source of truth)
- src/pricing.py          legacy stay pricing, still used by the front desk
- src/availability.py     legacy free-room search
- src/guests.py           legacy guest lookup
- src/guests_db.py        a tiny in-memory database with fake guests (do not change)
- bench.py                times one free-room search (do not change)
- data/, docs/, tests/    empty: you fill them during the exercise
- worksheet.md            your answers and a self-check

Setup: python -m pip install -r requirements.txt
Check: python -m pytest --version
To start again, unzip a fresh copy.
