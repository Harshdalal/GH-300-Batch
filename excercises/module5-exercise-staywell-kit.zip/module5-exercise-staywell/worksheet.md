# Module 5 practice exercise: worksheet

## Task 1. Explain the legacy pricing code
calc() in my own words (before asking Copilot):
Copilot's explanation, in one line:
Differences between calc() and R1 that I can see:

## Task 2. Document it
What the generated docstring or docs say about weekend nights:
What R1 says about weekend nights:
Other places where the generated docs describe the code, not the requirements:

## Task 3. Tests and edge cases
Number of tests:      Failed on the legacy code:      Passed:
Which R1 rows failed, and why?
Two extra edge cases Copilot suggested, and whether I kept them:

## Task 4. Refactor and fix
What changed (names, constants, type hints, rounding, rules):
Final test run: passed      failed
Does calc() still return the same as stay_price()? How do I know?

## Task 5. Sample data, overlap and speed
Sample data file and number of rows:
Which edge cases does the data include?
Which R2 rows failed on the legacy code?
bench.py before:      seconds      after:      seconds
Copilot's main performance suggestion:

## Task 6. Security review
The risk Copilot found in guests.py:
The test that proves it (input and result before the fix):
How the fix works:

## Self-check
- [ ] I can get a plain-language explanation of legacy code and compare it with the requirements.
- [ ] I can generate documentation and check it against the requirements, not the code.
- [ ] I can write tests from the requirements, including edge cases, with clear assertions.
- [ ] I can refactor and modernise code without changing behaviour that the tests protect.
- [ ] I can generate safe sample data that covers edge cases.
- [ ] I can ask for performance suggestions and measure the result.
- [ ] I can ask for a security review and prove a vulnerability with a test.
