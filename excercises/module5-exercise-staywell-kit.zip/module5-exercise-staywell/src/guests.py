# guests.py  (StayWell, 2018)


def find_guest(conn, email):
    sql = "SELECT id, name, email FROM guests WHERE email = '" + email + "'"
    return conn.execute(sql).fetchone()
