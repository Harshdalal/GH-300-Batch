"""Tiny in-memory guest database for the exercise. Do not change this file. All people are fake."""
import sqlite3


def make_db() -> sqlite3.Connection:
    """Return a connection to an in-memory database with two fake guests."""
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE guests (id INTEGER PRIMARY KEY, name TEXT, email TEXT)")
    conn.executemany(
        "INSERT INTO guests (id, name, email) VALUES (?, ?, ?)",
        [(1, "Asha Rao", "asha@example.com"), (2, "Ben Okoro", "ben@example.com")],
    )
    conn.commit()
    return conn
