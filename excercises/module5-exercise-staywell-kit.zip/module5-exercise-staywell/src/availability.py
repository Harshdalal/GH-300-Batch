# availability.py  (StayWell, 2017)


def free_rooms(rooms, bookings, a, b):
    result = []
    for r in rooms:
        busy = False
        for bk in bookings:
            if bk[0] == r:
                if bk[1] <= b and a <= bk[2]:
                    busy = True
        if busy == False:
            if r not in result:
                result.append(r)
    return result
