# pricing.py  (StayWell, 2016)
# do not touch, the front desk still uses calc()
import datetime


def calc(a, b, r):
    n = (b - a).days
    t = 0
    d = a
    for i in range(n):
        if d.weekday() >= 5:
            t = t + r * 1.25
        else:
            t = t + r
        d = d + datetime.timedelta(days=1)
    if n > 7:
        t = t * 0.9
    return round(t)
