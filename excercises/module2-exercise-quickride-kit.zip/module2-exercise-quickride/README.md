# Module 2 practice exercise kit: QuickRide bike rental

Practice for Module 2 (Use GitHub Copilot features). Do the main ShopEasy case study first.
Follow the tasks in Module2_Exercise_Problem_Statement.docx and write your own prompts.

- requirements.md   the fee rules and agreed examples (source of truth)
- team-rules.md     team rules you turn into Copilot instructions files in Task 4
- src/rental.py     existing code; you add rental_fee and receipt_line here
- tests/            empty: your tests go here
- worksheet.md      your answers and a self-check

There is no .github/ folder yet: you create it in Tasks 4 and 5.

Setup: python -m pip install -r requirements.txt
Check: python -m pytest --version
To start again, unzip a fresh copy.
