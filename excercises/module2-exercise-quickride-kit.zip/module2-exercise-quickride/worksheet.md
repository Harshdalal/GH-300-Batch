# Module 2 practice exercise: worksheet

## Task 1. Inline suggestion
What did the first suggestion use to count blocks?
How many alternative suggestions did you see? What was different?

## Task 2. Explain and edge cases
Edge cases I expected (before asking):
Edge cases Copilot listed:
Did Copilot notice anything about the blocks() helper?

## Task 3. Tests
Number of tests:      Failed before fix:      Passed after fix:
Which rows failed, and why?
Which file did the fix change?

## Task 4. Instructions files
Answer BEFORE the instructions files (summary):
Answer AFTER the instructions files (summary):

| Team rule | Followed before? | Followed after? |
|-----------|------------------|-----------------|
| int rupees, no float |  |  |
| type hints and docstring |  |  |
| parametrize, one row per example |  |  |
| test names test_r<n>_... |  |  |
| ids such as R2-1 |  |  |
| code first, at most three bullets |  |  |

Which instructions files appeared in the references list?

## Task 5. Prompt file
File name and path:
Command I typed in Chat:
What did it report?

## Task 6. Code review
Number of review comments:
The comment I accepted, and why:
The comment I rejected, and why:

## Self-check
- [ ] I can get, accept, dismiss and cycle inline suggestions.
- [ ] I can use a slash command and #file context in Chat.
- [ ] I can let Agent mode write and run tests, and approve its commands and edits.
- [ ] I can write a repository instructions file and a path-specific instructions file with applyTo.
- [ ] I can explain the difference between instructions files and prompt files.
- [ ] I can write a prompt file and run it with /name.
- [ ] I can ask Copilot to review code and decide which comments to accept.
