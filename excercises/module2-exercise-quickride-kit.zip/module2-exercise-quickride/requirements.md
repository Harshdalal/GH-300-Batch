# QuickRide bike rental: requirements

The product owner agreed these rules. This file is the source of truth.
All money is in whole rupees (integers). Never use floats for money.

## R1. rental_fee(minutes, is_member)

- minutes is the ride length in whole minutes. Below 1 raises ValueError.
- Fee = unlock fee 20 + 10 for every started block of 15 minutes.
  A started block counts in full: 1 to 15 minutes is one block, 16 to 30 is two blocks.
- Members (is_member True) do not pay the unlock fee.
- The fee for one ride never goes above 300 (the daily cap).

| ID | minutes | is_member | expected fee |
|----|---------|-----------|--------------|
| 1  | 1       | False     | 30           |
| 2  | 15      | False     | 30           |
| 3  | 16      | False     | 40           |
| 4  | 60      | False     | 60           |
| 5  | 60      | True      | 40           |
| 6  | 600     | False     | 300          |
| 7  | 0       | False     | ValueError   |

## R2. receipt_line(ride_id, minutes, fee)

- Returns one line of text: Ride <ride_id>: <minutes> min, Rs <fee>

| ID | ride_id | minutes | fee | expected result              |
|----|---------|---------|-----|------------------------------|
| 1  | QR-1042 | 16      | 40  | Ride QR-1042: 16 min, Rs 40  |
| 2  | QR-7    | 1       | 30  | Ride QR-7: 1 min, Rs 30      |
