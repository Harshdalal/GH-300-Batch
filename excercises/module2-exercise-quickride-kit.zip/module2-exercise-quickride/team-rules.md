# QuickRide team rules

Our team agreed these rules. Copilot does not know them yet: in the exercise you turn them into
files that Copilot reads.

## Rules for all code

- Money is a whole number of rupees (int). Never use float for money.
- Every function has type hints and a one-line docstring.
- Use only the Python standard library, plus pytest for tests.
- Expected values in tests come from requirements.md, never from the code under test.
- Answers in Chat: show the code first, then at most three short bullet points.

## Extra rules for test files only (files in tests/)

- Use @pytest.mark.parametrize with one row per example in requirements.md.
- Name each test function test_r<rule number>_<short name>, for example test_r1_fee.
- Each parametrized row has an id matching the requirements table, for example id="R1-3".
- Never import random or time in a test.
