"""QuickRide rental helpers. All money is in whole rupees."""

UNLOCK_FEE = 20
BLOCK_MINUTES = 15
BLOCK_PRICE = 10
DAILY_CAP = 300


def blocks(minutes: int) -> int:
    """Number of 15-minute blocks in a ride (helper written earlier with AI help)."""
    return minutes // BLOCK_MINUTES


# TASK 1: put your cursor on the empty line below.

