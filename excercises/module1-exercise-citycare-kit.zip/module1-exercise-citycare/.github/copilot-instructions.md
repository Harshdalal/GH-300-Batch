# Project rules for GitHub Copilot (CityCare Clinic)

- Expected values in tests come from requirements.md, never from the code under test.
- Never change a test to make it pass. Fix the code instead.
- Use only the Python standard library, plus pytest for tests.
- Do not invent functions or libraries. If you are not sure something exists, say so.
- Never print, log or copy patient data or tokens into answers, tests or logs.
- Put tests in the tests/ folder, one assert per behaviour.
