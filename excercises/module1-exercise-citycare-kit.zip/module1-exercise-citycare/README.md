# Module 1 practice exercise kit: CityCare Clinic

Practice for Module 1 (Use GitHub Copilot responsibly). Do the main ShopEasy case study first.
An AI assistant wrote five snippets for a clinic's appointment app. Review them, prove the defects,
fix what code can fix and decide what needs a person, using Copilot Chat.
Follow the tasks in Module1_Exercise_Problem_Statement.docx and write your own prompts.

- requirements.md                   five rules (R1 to R5) with agreed examples: the source of truth
- snippets/                         the five AI-written snippets (tokens and patient data are fake)
- data/reports/, data/private/      files used by snippet 1
- tests/                            empty: Copilot writes the tests here
- .github/copilot-instructions.md   project rules Copilot reads in every chat
- worksheet.md                      your answers and a self-check

Setup: python -m pip install -r requirements.txt
Check: python -m pytest --version
To start again, unzip a fresh copy.
