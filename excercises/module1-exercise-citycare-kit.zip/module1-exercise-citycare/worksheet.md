# Module 1 practice exercise: worksheet and self-check

Write your own answer before you ask Copilot. Then compare.

## Step 2. My risk list (before asking Copilot)

| File | Risk I see | Principle |
|------|------------|-----------|
| reports.py  |  |  |
| age.py      |  |  |
| preview.py  |  |  |
| priority.py |  |  |
| notify.py   |  |  |

Risks Copilot found that I missed:
Risks I found that Copilot missed:

## Step 3. Fact check

Copilot said textwrap.truncate exists? (yes / no / not sure):
The command printed:
Did the second model rank the risks differently? How?

## Step 4. Test results

Number of tests:      Failed:      Passed:
Which rule does each failure break?

## Step 6. Who decides?

| Snippet | Decision needed | Who decides or acts |
|---------|-----------------|---------------------|
| priority.py |  |  |
| notify.py   |  |  |

## Self-check: tick each one you can do without the manual

- [ ] I can show which file Copilot reads its project rules from, and explain why rules do not guarantee behaviour.
- [ ] I can map each risk to one of the six responsible AI principles.
- [ ] I can prove that an AI-suggested function does not exist.
- [ ] I can explain why two models, or two runs, give different answers.
- [ ] I can read an Agent mode command aloud before allowing it.
- [ ] I can review an edit and choose Keep or Undo.
- [ ] I can name which problems code can fix and which need a person.
- [ ] I can write a pull request note that is open about AI help.
