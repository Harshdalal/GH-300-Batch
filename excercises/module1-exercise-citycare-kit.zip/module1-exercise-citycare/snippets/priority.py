"""Snippet 4 of 5: priority score for the appointment waiting list (AI-generated, not yet reviewed)."""


def priority_score(p):
    score = 5 * p["urgency"] + min(p["days_waiting"], 30)
    if p["insurance"] == "premium":
        score += 20
    if p["age"] > 75:
        score -= 5
    if p["language"] != "English":
        score -= 10
    return score
