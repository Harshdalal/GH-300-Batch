"""Snippet 1 of 5: read a visit report (AI-generated, not yet reviewed)."""
import os

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "reports")


def read_report(filename):
    path = os.path.join(REPORTS_DIR, filename)
    with open(path, encoding="utf-8") as f:
        return f.read()
