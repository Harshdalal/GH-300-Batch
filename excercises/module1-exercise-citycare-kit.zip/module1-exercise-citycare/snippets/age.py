"""Snippet 2 of 5: a patient's age on a given date (AI-generated, not yet reviewed)."""


def age_on(birth_date, on_date):
    return on_date.year - birth_date.year
