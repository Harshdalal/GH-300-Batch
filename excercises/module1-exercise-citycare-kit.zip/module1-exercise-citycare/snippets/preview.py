"""Snippet 3 of 5: a short preview of a doctor's note (AI-generated, not yet reviewed)."""
import textwrap


def make_preview(note, width=20):
    return textwrap.truncate(note, width)
