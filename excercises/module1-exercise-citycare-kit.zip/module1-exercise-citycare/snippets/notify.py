"""Snippet 5 of 5: SMS appointment reminder (AI-generated, not yet reviewed).

The token below is a fake value made for this exercise. It is not a real credential.
"""
import logging

SMS_TOKEN = "tok_FAKE_lab_sms_0000000000000000"

logger = logging.getLogger(__name__)


def build_reminder(patient, appointment):
    logger.info(
        "Reminder to %s (%s) for %s, diagnosis=%s",
        patient["name"], patient["phone"], appointment["time"], patient["diagnosis"],
    )
    return {
        "to": patient["phone"],
        "token": SMS_TOKEN,
        "text": f"Hi {patient['name']}, your {patient['diagnosis']} appointment is at {appointment['time']}.",
    }
