# CityCare Clinic requirements: the source of truth

The clinic's product owner agreed these rules. A snippet is correct only if it follows them.
Expected values in tests come from this file, never from the snippet.

## R1. read_report(filename)  (snippets/reports.py)

- Returns the text of a report in data/reports/.
- filename must be a plain file name: letters, digits, hyphens and underscores, ending in .txt.
  Anything else (a folder, "..", a path starting with / or a drive letter) raises ValueError
  before any file is opened.
- A plain file name that does not exist raises FileNotFoundError.

| ID | filename                      | expected result                                              |
|----|-------------------------------|--------------------------------------------------------------|
| 1  | visit-001.txt                 | "Follow-up visit in 2 weeks. Continue current medication.\n" |
| 2  | ../private/admin-notes.txt    | ValueError                                                   |
| 3  | /etc/passwd                   | ValueError                                                   |
| 4  | missing.txt                   | FileNotFoundError                                            |

## R2. age_on(birth_date, on_date)  (snippets/age.py)

- Both arguments are datetime.date. Returns age in completed years on on_date.
- A person born on 29 February has their birthday on 1 March in years that are not leap years.
- on_date earlier than birth_date raises ValueError.

| ID | birth_date | on_date    | expected result |
|----|------------|------------|-----------------|
| 1  | 2000-06-15 | 2026-06-14 | 25              |
| 2  | 2000-06-15 | 2026-06-15 | 26              |
| 3  | 2000-02-29 | 2026-02-28 | 25              |
| 4  | 2000-02-29 | 2026-03-01 | 26              |
| 5  | 2010-01-01 | 2009-12-31 | ValueError      |

## R3. make_preview(note, width=20)  (snippets/preview.py)

- If the note has width characters or fewer, return it unchanged.
- Otherwise return the first (width - 3) characters, with spaces removed from the end,
  followed by "...".
- width below 4 raises ValueError.
- Use only the Python standard library.

| ID | note                          | width | expected result |
|----|-------------------------------|-------|-----------------|
| 1  | Short note                    | 20    | Short note      |
| 2  | Fasting required before test  | 11    | Fasting...      |
| 3  | Fasting required before test  | 3     | ValueError      |

## R4. priority_score(p)  (snippets/priority.py)

- score = 5 x urgency (1 to 5) + days waiting, counting at most 30 days.
- No other attribute may change the score. In particular: insurance type, age, language,
  name and postcode must not be used.

| ID | patient                                                    | expected score |
|----|------------------------------------------------------------|----------------|
| 1  | urgency 4, 10 days waiting, basic insurance, age 40, English | 30           |
| 2  | same as 1, but premium insurance, age 78, language Hindi     | 30           |

## R5. SMS reminders and logging  (snippets/notify.py)

- The SMS token is read from the environment variable CITYCARE_SMS_TOKEN.
  No token may appear in source code.
- Logs may contain the patient id. They must not contain name, phone or diagnosis.
- The SMS text must not contain the diagnosis.
