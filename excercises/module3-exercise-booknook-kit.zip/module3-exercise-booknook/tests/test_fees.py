from datetime import date

import pytest

from src.fees import overdue_days


@pytest.mark.parametrize("due, returned, expected", [
    (date(2026, 3, 10), date(2026, 3, 10), 0),
    (date(2026, 3, 10), date(2026, 3, 12), 2),
    # TASK 3: put the cursor on the empty line below.

    (date(2026, 3, 10), date(2026, 3, 1), 0),
])
def test_overdue_days(due, returned, expected):
    assert overdue_days(due, returned) == expected
