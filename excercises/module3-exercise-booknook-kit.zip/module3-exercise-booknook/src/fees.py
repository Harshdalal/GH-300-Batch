"""BookNook late fee helpers. All money is in whole rupees."""
from datetime import date


def overdue_days(due: date, returned: date) -> int:
    """Days a book was returned after its due date (0 if on time or early)."""
    # TASK 2: put the cursor on the empty line below.

    return max(days, 0)


# TASK 1: put the cursor on the empty line below.

