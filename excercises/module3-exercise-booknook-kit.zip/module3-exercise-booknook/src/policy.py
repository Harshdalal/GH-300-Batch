"""BookNook lending policy. All money is in whole rupees."""

LOAN_DAYS = 14          # a book is lent for 14 days
GRACE_DAYS = 2          # no fee for the first 2 days after the due date
LATE_FEE_PER_DAY = 5    # rupees per day after the grace period
MAX_LATE_FEE = 150      # the fee for one book never goes above this
