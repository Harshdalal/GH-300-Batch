# BookNook late fee rules (source of truth)

The values live in src/policy.py. All money is in whole rupees.

## overdue_days(due, returned)

Days between the due date and the return date. 0 if the book came back on time or early.

## late_fee(days_overdue)

- No fee for the first GRACE_DAYS (2) days overdue.
- After that, LATE_FEE_PER_DAY (5) rupees for each extra day.
- The fee never goes above MAX_LATE_FEE (150).

| days_overdue | expected late_fee |
|--------------|-------------------|
| 0            | 0                 |
| 2            | 0                 |
| 3            | 5                 |
| 10           | 40                |
| 40           | 150               |

## Note on data

data/members.csv holds made-up member records for this exercise. Treat it as if it were real
personal data.
