# Module 3 practice exercise kit: BookNook library late fees

Practice for Module 3 (Understand GitHub Copilot data and architecture). Do the main
"trace one suggestion" case study first.
Follow the tasks in Module3_Exercise_Problem_Statement.docx and write your own prompts.

- rules.md            the late fee rules and examples (source of truth)
- src/policy.py       lending policy values (a neighbour file)
- src/fees.py         code to finish (Tasks 1 and 2)
- tests/test_fees.py  tests with a gap in the data (Task 3)
- data/members.csv    made-up member records (Task 4)
- worksheet.md        your answers and a self-check

Setup: python -m pip install -r requirements.txt
Check: python -m pytest --version
To start again, unzip a fresh copy.
