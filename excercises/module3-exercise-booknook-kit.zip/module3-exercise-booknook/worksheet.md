# Module 3 practice exercise: worksheet

Write your own answer first where a task says so. Then ask Copilot. Then compare.

## Task 1. Three runs, three contexts

| Run | What Copilot could see | Used GRACE_DAYS? | Used the cap of 150? | late_fee(3) | late_fee(40) |
|-----|------------------------|------------------|----------------------|-------------|--------------|
| A   | comment only, policy.py closed |  |  |  |  |
| B   | policy.py open in a tab        |  |  |  |  |
| C   | policy.py closed, import line added |  |  |  |  |

Which run matched rules.md best, and why?

## Task 2. Fill in the middle of a function
The line Copilot suggested:
Why does it fit the line that follows the cursor?
Test result after accepting:

## Task 3. Fill in the middle of test data
The row Copilot suggested:
Expected value I worked out by hand:
Did they match? Test result:

## Task 4. What Copilot can see
Answer without #file:
Answer with #file:
Correct answer (count by hand):
Is it a good idea to send this file to Copilot? Why?

## Task 5. Sort eight scenarios into lifecycle steps (1 to 8)

| Scenario | My step | Copilot's step |
|----------|---------|----------------|
| S1 |  |  |
| S2 |  |  |
| S3 |  |  |
| S4 |  |  |
| S5 |  |  |
| S6 |  |  |
| S7 |  |  |
| S8 |  |  |

## Task 6. The working-days function
The name Copilot used:
My verification command and what it printed:
Real or invented? Standard library or not?

## Task 7. Data handling quiz (True or False)

| Statement | My answer | Copilot's answer | Official page says | Page and date checked |
|-----------|-----------|------------------|--------------------|-----------------------|
| Q1 |  |  |  |  |
| Q2 |  |  |  |  |
| Q3 |  |  |  |  |
| Q4 |  |  |  |  |
| Q5 |  |  |  |  |
| Q6 |  |  |  |  |
| Q7 |  |  |  |  |

## Challenge. Knowledge cutoff
Copilot's answer:
python.org says:

## Self-check
- [ ] I can show that open tabs and import lines change what Copilot suggests.
- [ ] I can explain fill-in-the-middle with an example from code and from test data.
- [ ] I can explain why Copilot can only use the context it gathered or was given.
- [ ] I can place any event in the right step of the eight-step lifecycle.
- [ ] I can prove whether a function Copilot used really exists.
- [ ] I can answer data handling questions from the official pages, with a date.
- [ ] I can name at least three limitations of LLMs and of Copilot.
