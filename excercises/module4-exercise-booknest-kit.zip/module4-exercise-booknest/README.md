# Module 4 practice exercise kit: BookNest Library

Practice for Module 4 (Apply prompt engineering and context crafting). Do the main ShopEasy
case study first. Follow the tasks in Module4_Exercise_Problem_Statement.docx and write your
own prompts.

- requirements.md          rules R1 to R5 with agreed examples (source of truth)
- src/                     five empty functions to prompt for, plus library_config.py (settings)
- tests/                   ready-made checks that score each prompt; do not edit them
- worksheet.md             your prompts, scores, notes and a self-check

Setup: python -m pip install -r requirements.txt
Starting score: python -m pytest -q   (33 failed)
Score one function: python -m pytest -q tests/test_fees.py
To start again, unzip a fresh copy.
