"""BookNest: loans."""

import datetime as dt


def due_date(loan_date: dt.date, item_type: str) -> dt.date:
    """Due date for a loan."""
    raise NotImplementedError
