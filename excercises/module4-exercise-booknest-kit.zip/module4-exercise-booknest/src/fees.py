"""BookNest: fees."""


def late_fee(days_late: int, member_type: str) -> int:
    """Late fee in rupees for one item."""
    raise NotImplementedError
