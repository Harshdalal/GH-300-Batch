"""BookNest: isbn."""


def normalise_isbn(text: str) -> str:
    """Normalised ISBN-13 for an ISBN."""
    raise NotImplementedError
