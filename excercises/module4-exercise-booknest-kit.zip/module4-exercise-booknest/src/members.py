"""BookNest: members."""


def member_id(number: int) -> str:
    """Member ID with a check letter."""
    raise NotImplementedError
