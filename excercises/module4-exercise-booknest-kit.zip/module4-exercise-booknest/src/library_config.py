"""BookNest settings. Do not change this file."""
import datetime as dt

# Loan period in days for each item type.
LOAN_DAYS = {"book": 21, "dvd": 7, "magazine": 7}

# The library is closed every Sunday (weekday 6) and on these dates.
CLOSED_WEEKDAYS = {6}
CLOSED_DATES = {dt.date(2026, 12, 25), dt.date(2026, 12, 26), dt.date(2027, 1, 1)}
