"""BookNest: shelf."""


def shelf_code(title: str, author_surname: str, year: int) -> str:
    """Shelf code for a book."""
    raise NotImplementedError
