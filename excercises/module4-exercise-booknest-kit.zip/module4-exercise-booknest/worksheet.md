# Module 4 practice exercise: worksheet

After every prompt, run the checks yourself and write the score, for example "7 passed, 2 failed".
Copy every prompt you send into the Prompt column, word for word.

## Scores

| Task | Prompt (copy it here) | Checks file | Passed | Failed |
|------|-----------------------|-------------|--------|--------|
| 1a   |                       | test_fees.py  | | |
| 1b   |                       | test_fees.py  | | |
| 2a   |                       | test_shelf.py | | |
| 2b   |                       | test_shelf.py | | |
| 3a   |                       | test_loans.py | | |
| 3b   |                       | test_loans.py | | |
| 4 round 1 |                  | test_isbn.py  | | |
| 4 round 2 |                  | test_isbn.py  | | |
| 4 round 3 |                  | test_isbn.py  | | |
| 5a   |                       | test_members.py | | |
| 5b   |                       | test_members.py | | |

## Task 1. Prompt structure
Which parts did my structured prompt have? (goal / context / rules and constraints / examples / output format / what not to do)

## Task 2. Zero-shot and few-shot
Which of the 9 shelf checks failed after 2a? After 2b?
The last 4 checks use books that are not in requirements.md. What does passing them prove?

## Task 3. Context
Which file did Copilot need in 3b that it did not have in 3a?
Did Copilot invent any loan periods or closed days in 3a? Which?

## Task 4. Iterating
What did I add to the prompt in each round? (for example: a failing check's output, a rule, an example)
How many rounds did it take to reach 5 passed?

## Task 5. Chat history
What did Copilot do with the short follow-up in 5a? Which earlier task did it carry over?
Why did the new chat in 5b work better (or not)?

## Task 6. My prompt template
Paste my template here:

Copilot's three suggestions to improve it:

Which suggestion did I accept, and why?

## Self-check
- [ ] I can turn a vague request into a prompt with a goal, context, constraints and an expected output.
- [ ] I can explain zero-shot and few-shot prompting and when examples help.
- [ ] I can tell whether code follows a pattern or only copies the examples.
- [ ] I can add the right context with #file and say why Copilot needed it.
- [ ] I can iterate on a prompt using test output as feedback.
- [ ] I can explain when to continue a chat and when to start a new one.
- [ ] I can write a reusable prompt template and improve it with Copilot's help.
