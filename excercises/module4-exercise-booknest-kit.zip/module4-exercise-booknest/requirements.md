# BookNest Library: requirements

The library's product owner agreed these rules. This file is the source of truth.
All money is in whole rupees (integers).

## R1. late_fee(days_late, member_type)

- member_type is "standard", "student" or "senior". Any other value raises ValueError.
- days_late below 0 raises ValueError.
- The first 2 days late are free (grace period) for everyone.
- After the grace period, each day costs 5 (standard), 3 (student) or 2 (senior).
- The fee for one item never goes above 100.

| ID | days_late | member_type | expected fee |
|----|-----------|-------------|--------------|
| 1  | 0         | standard    | 0            |
| 2  | 2         | standard    | 0            |
| 3  | 3         | standard    | 5            |
| 4  | 10        | standard    | 40           |
| 5  | 10        | student     | 24           |
| 6  | 5         | senior      | 6            |
| 7  | 40        | standard    | 100          |
| 8  | -1        | standard    | ValueError   |
| 9  | 3         | vip         | ValueError   |

## R2. shelf_code(title, author_surname, year)

The cataloguing team never wrote this rule down. They only gave these examples.
Your code must follow the same pattern for any book, not just these five.

| ID | title                    | author_surname | year | expected result |
|----|--------------------------|----------------|------|-----------------|
| 1  | The Hobbit               | Tolkien        | 1937 | TOL-HOB-37      |
| 2  | Dune                     | Herbert        | 1965 | HER-DUN-65      |
| 3  | A Brief History of Time  | Hawking        | 1988 | HAW-BRI-88      |
| 4  | It                       | King           | 1986 | KIN-ITX-86      |
| 5  | An Ode                   | Li             | 2001 | LIX-ODE-01      |

## R3. due_date(loan_date, item_type)

- loan_date is a datetime.date. Returns the due date as a datetime.date.
- The loan period for each item type, and the days the library is closed, are set in
  src/library_config.py. An item type that is not listed there raises ValueError.
- If the due date falls on a day the library is closed, move it to the next open day.

| ID | loan_date  | item_type | expected due date |
|----|------------|-----------|-------------------|
| 1  | 2026-11-02 | book      | 2026-11-23        |
| 2  | 2026-11-02 | dvd       | 2026-11-09        |
| 3  | 2026-11-01 | dvd       | 2026-11-09        |
| 4  | 2026-12-18 | dvd       | 2026-12-28        |
| 5  | 2026-12-19 | magazine  | 2026-12-28        |
| 6  | 2026-11-02 | ebook     | ValueError        |

## R4. normalise_isbn(text)

- Remove spaces and hyphens.
- A valid ISBN-13 (13 digits, correct check digit) is returned as 13 digits.
- A valid ISBN-10 (9 digits then a digit or X or x, correct check digit) is converted to
  ISBN-13: "978" + its first 9 digits + a new ISBN-13 check digit.
- Anything else raises ValueError.

| ID | text               | expected result |
|----|--------------------|-----------------|
| 1  | 978-0-306-40615-7  | 9780306406157   |
| 2  | 0-306-40615-2      | 9780306406157   |
| 3  | 080442957X         | 9780804429573   |
| 4  | 978-0-306-40615-8  | ValueError      |
| 5  | 12345              | ValueError      |

## R5. member_id(number)

- number is a whole number from 1 to 999999. Anything else raises ValueError.
- Format: BN-, the number as 6 digits with leading zeros, a hyphen, then a check letter.
- Check letter: add up the 6 digits, take the remainder after dividing by 10, and pick that
  position (counting from 0) in the letters ABCDEFGHJK.

| ID | number  | expected result |
|----|---------|-----------------|
| 1  | 42      | BN-000042-G     |
| 2  | 999999  | BN-999999-E     |
| 3  | 0       | ValueError      |
| 4  | 1000000 | ValueError      |
