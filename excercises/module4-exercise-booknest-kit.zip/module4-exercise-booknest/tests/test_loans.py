"""Ready-made checks for R3. They only score: do not edit."""
import datetime as dt
import pytest
from src.loans import due_date

D = dt.date.fromisoformat


@pytest.mark.parametrize("loan,item,expected", [
    ("2026-11-02", "book", "2026-11-23"), ("2026-11-02", "dvd", "2026-11-09"),
    ("2026-11-01", "dvd", "2026-11-09"), ("2026-12-18", "dvd", "2026-12-28"),
    ("2026-12-19", "magazine", "2026-12-28"),
])
def test_due(loan, item, expected):
    assert due_date(D(loan), item) == D(expected)


def test_due_unknown_type():
    with pytest.raises(ValueError):
        due_date(D("2026-11-02"), "ebook")
