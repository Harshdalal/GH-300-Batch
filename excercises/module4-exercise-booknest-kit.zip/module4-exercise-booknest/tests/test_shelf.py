"""Ready-made checks for R2. They only score: do not edit.
The last four books are NOT in requirements.md: they check the pattern, not the examples."""
import pytest
from src.shelf import shelf_code


@pytest.mark.parametrize("title,author,year,expected", [
    ("The Hobbit", "Tolkien", 1937, "TOL-HOB-37"),
    ("Dune", "Herbert", 1965, "HER-DUN-65"),
    ("A Brief History of Time", "Hawking", 1988, "HAW-BRI-88"),
    ("It", "King", 1986, "KIN-ITX-86"),
    ("An Ode", "Li", 2001, "LIX-ODE-01"),
    ("Emma", "Austen", 1815, "AUS-EMM-15"),
    ("The Road", "McCarthy", 2006, "MCC-ROA-06"),
    ("Ox", "Wu", 2020, "WUX-OXX-20"),
    ("Anthem", "Rand", 1938, "RAN-ANT-38"),
])
def test_shelf(title, author, year, expected):
    assert shelf_code(title, author, year) == expected
