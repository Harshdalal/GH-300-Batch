"""Ready-made checks for R4. They only score: do not edit."""
import pytest
from src.isbn import normalise_isbn


@pytest.mark.parametrize("text,expected", [
    ("978-0-306-40615-7", "9780306406157"), ("0-306-40615-2", "9780306406157"),
    ("080442957X", "9780804429573"),
])
def test_isbn(text, expected):
    assert normalise_isbn(text) == expected


@pytest.mark.parametrize("text", ["978-0-306-40615-8", "12345"])
def test_isbn_errors(text):
    with pytest.raises(ValueError):
        normalise_isbn(text)
