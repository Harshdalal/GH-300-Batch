"""Ready-made checks for R1. They only score: do not edit."""
import pytest
from src.fees import late_fee


@pytest.mark.parametrize("days,member,expected", [
    (0, "standard", 0), (2, "standard", 0), (3, "standard", 5), (10, "standard", 40),
    (10, "student", 24), (5, "senior", 6), (40, "standard", 100),
])
def test_fee(days, member, expected):
    assert late_fee(days, member) == expected


@pytest.mark.parametrize("days,member", [(-1, "standard"), (3, "vip")])
def test_fee_errors(days, member):
    with pytest.raises(ValueError):
        late_fee(days, member)
