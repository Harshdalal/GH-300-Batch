"""Ready-made checks for R5. They only score: do not edit."""
import pytest
from src.members import member_id


@pytest.mark.parametrize("number,expected", [(42, "BN-000042-G"), (999999, "BN-999999-E")])
def test_member(number, expected):
    assert member_id(number) == expected


@pytest.mark.parametrize("number", [0, 1000000])
def test_member_errors(number):
    with pytest.raises(ValueError):
        member_id(number)
