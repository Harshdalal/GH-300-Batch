# GH-300 capstone kit: TripTrack travel expenses

Follow GH300_Capstone_Problem_Statement.docx. Work alone, about 45 minutes, prompts written by you.

- requirements.md        R1 to R5: the source of truth
- team-rules.md          team rules to turn into Copilot instruction files (Task 2)
- src/expenses.py        empty functions for R1 and R2 (Task 3)
- src/receipts.py        empty function for R4 (Task 3)
- src/legacy_approval.py old code for R3 (Task 5)
- src/audit_log.py       AI-written logging for R5 (Task 1)
- config/                rates and limits; a FAKE secrets file
- data/                  sample claims and FAKE employee data
- certs/                 a FAKE key file
- tests/checks/          acceptance checks: run them, never edit them
- tests/                 your own tests go here
- tools/check_rules.py   checks your content exclusion rules (Task 6)
- tools/bench_duplicates.py  times the duplicate finder (Task 5)
- exclusion-rules.yml    your content exclusion rules (Task 6)
- worksheet.md           your answers and self-check

Setup:  python -m pip install -r requirements.txt
Checks: python -m pytest tests/checks -q
All secrets, keys and personal data in this kit are fake.
