"""Practice checker for Copilot content exclusion rules (repository level format).

This is a LOCAL APPROXIMATION for practice. GitHub does the real matching, in your
organization settings. Run:  python tools/check_rules.py [rules-file] [policy-file]
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).parent


def glob_to_regex(pattern):
    """Turn an fnmatch-style pattern into a regex. ** crosses folders, * does not."""
    p, i, out = pattern, 0, ""
    while i < len(p):
        c = p[i]
        if p.startswith("**/", i):
            out += "(?:.*/)?"; i += 3; continue
        if p.startswith("**", i):
            out += ".*"; i += 2; continue
        if c == "*": out += "[^/]*"
        elif c == "?": out += "[^/]"
        elif c == "{":
            j = p.index("}", i)
            out += "(?:" + "|".join(re.escape(x) for x in p[i + 1:j].split(",")) + ")"
            i = j
        elif c == "[":
            j = p.index("]", i)
            out += p[i:j + 1]; i = j
        else: out += re.escape(c)
        i += 1
    return out


def matches(pattern, path):
    """path looks like /config/secrets.json. Case-insensitive."""
    if "/" not in pattern:                     # no slash: match the file name anywhere
        return re.fullmatch(glob_to_regex(pattern), path.rsplit("/", 1)[-1], re.I) is not None
    if not pattern.startswith(("/", "**")):    # a/b/*.x: treat as anchored at the root
        pattern = "/" + pattern
    return re.fullmatch(glob_to_regex(pattern), path, re.I) is not None


def load_rules(rules_file):
    rules, scope = [], None
    for raw in Path(rules_file).read_text(encoding="utf8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith(":") and not line.startswith("-"):
            scope = line[:-1].strip().strip('"')
            continue
        m = re.match(r'^-\s*"?(.*?)"?\s*$', line)
        if m and m.group(1):
            if scope in (None, "*"):
                rules.append(m.group(1))
            else:
                print(f"note: skipped '{m.group(1)}' (belongs to repository reference {scope})")
    return rules


def main():
    rules_file = sys.argv[1] if len(sys.argv) > 1 else ROOT.parent / "exclusion-rules.yml"
    policy_file = sys.argv[2] if len(sys.argv) > 2 else ROOT / "policy.txt"
    rules = load_rules(rules_file)
    print(f"{len(rules)} rule(s) loaded from {Path(rules_file).name}")
    bad = 0
    for raw in Path(policy_file).read_text(encoding="utf8").splitlines():
        if not raw.strip() or raw.startswith("#"):
            continue
        kind, path = raw.split(None, 1)
        hit = next((r for r in rules if matches(r, path)), None)
        ok = (hit is not None) if kind == "EXCLUDE" else (hit is None)
        bad += 0 if ok else 1
        note = f"blocked by {hit!r}" if hit else "not blocked"
        print(f"{'PASS' if ok else 'FAIL'}  {kind:<7} {path:<28} {note}")
    print("All policy lines pass." if bad == 0 else f"{bad} line(s) fail. Fix exclusion-rules.yml in the project root and run again.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
