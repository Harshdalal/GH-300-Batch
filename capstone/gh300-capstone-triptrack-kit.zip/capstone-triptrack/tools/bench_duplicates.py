"""Time find_duplicates on 6,000 fake expenses. Run: python tools/bench_duplicates.py"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.legacy_approval import find_duplicates  # noqa: E402

expenses = [
    {"claim_id": f"C{i}", "date": f"2026-10-{i % 28 + 1:02d}", "amount_minor": i % 500, "currency": "INR"}
    for i in range(6000)
]
start = time.perf_counter()
dups = find_duplicates(expenses)
print(f"{len(dups)} duplicates found in {time.perf_counter() - start:.3f} seconds")
