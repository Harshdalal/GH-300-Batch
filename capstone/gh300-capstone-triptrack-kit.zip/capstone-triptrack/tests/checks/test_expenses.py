"""Acceptance checks for R1 and R2. Do not edit."""
import pytest
from src.expenses import convert_to_inr, claim_total


@pytest.mark.parametrize("amount,cur,expected", [
    pytest.param(1000, "USD", 83500, id="R1-1"),
    pytest.param(199, "EUR", 17950, id="R1-2"),
    pytest.param(5, "GBP", 529, id="R1-3"),
    pytest.param(3, "USD", 251, id="R1-4"),
    pytest.param(100, "INR", 100, id="R1-5"),
    pytest.param(6, "GBP", 635, id="R1-extra-half-up"),
])
def test_r1_convert(amount, cur, expected):
    result = convert_to_inr(amount, cur)
    assert isinstance(result, int)
    assert result == expected


@pytest.mark.parametrize("amount,cur", [
    pytest.param(-1, "USD", id="R1-6"),
    pytest.param(500, "JPY", id="R1-7"),
])
def test_r1_errors(amount, cur):
    with pytest.raises(ValueError):
        convert_to_inr(amount, cur)


def e(date, cat, amt, cur):
    return {"date": date, "category": cat, "amount_minor": amt, "currency": cur}


@pytest.mark.parametrize("expenses,expected", [
    pytest.param([e("2026-10-01", "taxi", 1000, "USD")], 83500, id="R2-1"),
    pytest.param([e("2026-10-01", "meal", 100000, "INR"), e("2026-10-01", "meal", 80000, "INR")], 150000, id="R2-2"),
    pytest.param([e("2026-10-01", "meal", 100000, "INR"), e("2026-10-02", "meal", 100000, "INR")], 200000, id="R2-3"),
    pytest.param([], 0, id="R2-4"),
    pytest.param([e("2026-10-01", "meal", 2000, "USD"), e("2026-10-01", "taxi", 100000, "INR")], 250000, id="R2-5"),
    pytest.param([e("2026-10-03", "hotel", 900000, "INR"), e("2026-10-03", "meal", 160000, "INR")], 1050000, id="R2-extra-only-meals-capped"),
])
def test_r2_claim_total(expenses, expected):
    assert claim_total(expenses) == expected
