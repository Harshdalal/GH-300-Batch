"""Acceptance checks for R4. Do not edit. Some ids are not in requirements.md on purpose."""
import pytest
from src.receipts import receipt_id_valid


@pytest.mark.parametrize("rid,expected", [
    pytest.param("TT-2026-000123", True, id="R4-1"),
    pytest.param("TT-2025-999999", True, id="R4-2"),
    pytest.param("TT-26-000123", False, id="R4-3"),
    pytest.param("tt-2026-000123", False, id="R4-4"),
    pytest.param("TT-2026-12345", False, id="R4-5"),
    pytest.param("TT-2026-0001234", False, id="R4-6"),
    pytest.param("XX-2026-000123", False, id="R4-7"),
    pytest.param("TT-2031-000001", True, id="R4-new-1"),
    pytest.param("TT-2026-00012A", False, id="R4-new-2"),
    pytest.param(" TT-2026-000123", False, id="R4-new-3"),
    pytest.param("TT-2026-000123\n", False, id="R4-new-4"),
])
def test_r4_receipt(rid, expected):
    assert receipt_id_valid(rid) is expected
