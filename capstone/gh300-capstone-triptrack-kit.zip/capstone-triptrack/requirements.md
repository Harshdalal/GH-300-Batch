# TripTrack requirements: the source of truth

All money is in paise (int). 100 paise = 1 rupee. Rates and limits are in config/rates.py.

## R1. convert_to_inr(amount_minor, currency)  (src/expenses.py)

- amount_minor is in the currency's minor unit (cents, paise, pence).
- Result in paise = amount_minor x RATES[currency] / 100, rounded half up.
- A negative amount or an unknown currency raises ValueError.

| ID   | amount_minor | currency | expected paise |
|------|--------------|----------|----------------|
| R1-1 | 1000         | USD      | 83500          |
| R1-2 | 199          | EUR      | 17950          |
| R1-3 | 5            | GBP      | 529            |
| R1-4 | 3            | USD      | 251            |
| R1-5 | 100          | INR      | 100            |
| R1-6 | -1           | USD      | ValueError     |
| R1-7 | 500          | JPY      | ValueError     |

## R2. claim_total(expenses)  (src/expenses.py)

- expenses is a list of dicts with keys date, category, amount_minor, currency.
- Total = sum of every expense converted with R1.
- Meals are capped: all expenses with category "meal" on the same date count for at most
  DAILY_MEAL_CAP_PAISE (150000) together. Other categories have no cap.

| ID   | expenses                                                        | expected paise |
|------|-----------------------------------------------------------------|----------------|
| R2-1 | taxi 1000 USD on 10-01                                          | 83500          |
| R2-2 | meal 100000 INR and meal 80000 INR, both on 10-01               | 150000         |
| R2-3 | meal 100000 INR on 10-01 and meal 100000 INR on 10-02           | 200000         |
| R2-4 | no expenses                                                     | 0              |
| R2-5 | meal 2000 USD on 10-01 and taxi 100000 INR on 10-01             | 250000         |

## R3. Legacy approval module  (src/legacy_approval.py)

needs_manager_approval(total_paise, level)
- A claim of MANAGER_APPROVAL_PAISE (50,000 rupees) or more needs a manager, except when
  level is "director". Below that limit, no approval is needed.

| ID   | total_paise | level    | expected |
|------|-------------|----------|----------|
| R3-1 | 4999999     | staff    | False    |
| R3-2 | 5000000     | staff    | True     |
| R3-3 | 7500000     | manager  | True     |
| R3-4 | 9000000     | director | False    |

find_duplicates(expenses)
- Returns the claim ids of every expense that has the same date, amount_minor and currency
  as an EARLIER expense in the list, in list order.

| ID   | expenses (claim_id: date, amount, currency)                  | expected      |
|------|--------------------------------------------------------------|---------------|
| R3-5 | C1: 10-01 500 INR, C2: 10-01 500 INR, C3: 10-02 500 INR      | ["C2"]        |
| R3-6 | C1: 10-01 500 INR, C2: 10-01 500 USD                         | []            |
| R3-7 | C1, C2, C3 all: 10-01 500 INR                                | ["C2", "C3"]  |

get_employee(conn, emp_id)
- Returns (emp_id, level) or None. emp_id is always data: it must never change the SQL.

## R4. receipt_id_valid(receipt_id)  (src/receipts.py)

There is no written rule. The finance team gave only these examples. Find the pattern.

| ID   | receipt_id         | valid? |
|------|--------------------|--------|
| R4-1 | TT-2026-000123     | True   |
| R4-2 | TT-2025-999999     | True   |
| R4-3 | TT-26-000123       | False  |
| R4-4 | tt-2026-000123     | False  |
| R4-5 | TT-2026-12345      | False  |
| R4-6 | TT-2026-0001234    | False  |
| R4-7 | XX-2026-000123     | False  |

## R5. Audit logging  (src/audit_log.py)

- The audit log may contain the employee id, the claim id and the total.
- It must not contain names, PAN numbers or bank details.
