# GH-300 capstone: TripTrack worksheet

Fill this in as you go. Hand it in with your project folder.

## Task 1. Review (Module 1)

| File | Risk | Responsible AI principle | Can code fix it? | Who decides or acts |
|------|------|--------------------------|------------------|---------------------|
| src/legacy_approval.py |  |  |  |  |
| src/legacy_approval.py |  |  |  |  |
| src/legacy_approval.py |  |  |  |  |
| src/audit_log.py |  |  |  |  |

## Task 2. Project rules (Module 2)

Files I created (paths):
Did Copilot list them in its references? (yes / no):

## Task 3. Build with prompts (Module 4)

| Prompt | Technique | Checks passed (of total) |
|--------|-----------|--------------------------|
| R1 and R2, first attempt |  |  |
| R1 and R2, improved |  |  |
| R4, zero-shot |  |  |
| R4, few-shot |  |  |

What made the biggest difference:

## Task 4. Trace one suggestion (Module 3)

Files Copilot listed as references for my best Task 3 prompt:
Lifecycle steps, in order, for that prompt (1 to 8):
One thing Copilot's filters would NOT have caught in my Task 3 code:
Is my prompt data kept by GitHub? It depends on (plan, surface):

## Task 5. Legacy code (Module 5)

Failing R3 tests before any fix:
Benchmark before:            after:
Security fix (one line):
Refactor kept every test green? (yes / no):

## Task 6. Content exclusion (Module 6)

Rules in exclusion-rules.yml:
Checker result:
Copilot features that do NOT honour exclusion today (check the docs, note the date):
Why is exclusion not enough for config/secrets.env?

## Task 7. Ship it (Modules 1 and 2)

Prompt file path and command:
Code review: comment applied / comment rejected, with reasons:
Pull request note (3 to 5 lines):

## Self-check
- [ ] Every acceptance check in tests/checks passes, and I did not edit tests/checks.
- [ ] My own R3 tests are in tests/ and pass.
- [ ] tools/check_rules.py reports that all policy lines pass.
- [ ] I can name which problems needed a person, not Copilot.
