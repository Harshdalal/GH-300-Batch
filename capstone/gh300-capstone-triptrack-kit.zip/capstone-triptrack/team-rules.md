# TripTrack team rules

Turn these into Copilot instruction files in Task 2.

## For all code
- Money is an int number of paise. Never use float for money.
- Round half up. Do not use Python's built-in round(), which rounds half to even.
- Every function has type hints and a one-line docstring.
- Use only the Python standard library, plus pytest for tests.
- Never log or print names, PAN numbers or bank details. Logging the employee id is fine.
- Read secrets from environment variables. Never write a secret in code.

## For test files only (tests/)
- Expected values come from requirements.md, never from the code under test.
- Use @pytest.mark.parametrize with an id that matches the requirements table, such as "R3-2".
- Never edit files in tests/checks/. They are the acceptance checks.
