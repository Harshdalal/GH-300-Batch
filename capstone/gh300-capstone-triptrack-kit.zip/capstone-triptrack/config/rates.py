"""Exchange rates: INR paise for one major unit of each currency (fixed for this exercise)."""

RATES = {
    "INR": 100,      # 1 rupee = 100 paise
    "USD": 8350,     # 1 US dollar = 83.50 rupees
    "EUR": 9020,     # 1 euro = 90.20 rupees
    "GBP": 10575,    # 1 pound = 105.75 rupees
}

DAILY_MEAL_CAP_PAISE = 150000   # 1,500 rupees per day for meals
MANAGER_APPROVAL_PAISE = 5000000  # 50,000 rupees
