# approval stuff - old code, do not touch?? (written 2019, partly by an AI tool)
from config.rates import MANAGER_APPROVAL_PAISE


def needs_manager_approval(t, l):
    if l == "director":
        return False
    if t > MANAGER_APPROVAL_PAISE:
        return True
    else:
        return False


def find_duplicates(exp):
    res = []
    for i in range(len(exp)):
        for j in range(len(exp)):
            if j < i:
                a = exp[i]; b = exp[j]
                if a["date"] == b["date"] and a["amount_minor"] == b["amount_minor"] and a["currency"] == b["currency"]:
                    if a["claim_id"] not in res:
                        res.append(a["claim_id"])
    return res


def get_employee(conn, emp_id):
    q = "SELECT emp_id, level FROM employees WHERE emp_id = '" + emp_id + "'"
    return conn.execute(q).fetchone()
