"""Audit logging for approved claims (AI-generated, not yet reviewed)."""
import logging

logger = logging.getLogger("triptrack.audit")


def log_approved(claim_id, employee, total_paise):
    logger.info(
        "Claim %s approved for %s (PAN %s, bank %s): %d paise",
        claim_id, employee["name"], employee["pan"], employee["bank_account"], total_paise,
    )
