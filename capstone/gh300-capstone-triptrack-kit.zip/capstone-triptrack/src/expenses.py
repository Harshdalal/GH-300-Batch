"""TripTrack expense calculations. All money is in paise (int)."""
from config.rates import RATES, DAILY_MEAL_CAP_PAISE


def convert_to_inr(amount_minor: int, currency: str) -> int:
    """Task 3: implement R1 with a prompt."""
    raise NotImplementedError


def claim_total(expenses: list[dict]) -> int:
    """Task 3: implement R2 with a prompt."""
    raise NotImplementedError
