"""TripTrack receipt checks."""


def receipt_id_valid(receipt_id: str) -> bool:
    """Task 3: implement R4 with a few-shot prompt."""
    raise NotImplementedError
